import { useNavigate } from "react-router-dom";
import { User, Mail, Shield, Calendar, LogOut, Key, Activity } from "lucide-react";
import AuthService from "../services/auth.service";

const Profile = () => {
    const user = AuthService.getCurrentUser();
    const navigate = useNavigate();

    if (!user) {
        navigate("/login");
        return null;
    }

    const handleLogout = () => {
        AuthService.logout();
        window.location.reload();
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="glass-panel overflow-hidden">
                {/* Profile Header Background */}
                <div className="h-32 bg-gradient-to-r from-primary/20 via-secondary/20 to-primary/20 relative">
                    <div className="absolute -bottom-12 left-8">
                        <div className="w-24 h-24 rounded-2xl bg-surface border-4 border-background flex items-center justify-center shadow-xl">
                            <User className="w-12 h-12 text-primary" />
                        </div>
                    </div>
                </div>

                <div className="pt-16 pb-8 px-8">
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-3xl font-bold text-white tracking-tight">{user.username}</h1>
                            <p className="text-textMuted flex items-center mt-1">
                                <Mail className="w-4 h-4 mr-2" />
                                {user.email}
                            </p>
                        </div>
                        <button
                            onClick={handleLogout}
                            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors border border-red-500/20"
                        >
                            <LogOut className="w-4 h-4" />
                            <span className="font-medium text-sm">Sign Out</span>
                        </button>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Account Details */}
                <div className="md:col-span-2 space-y-6">
                    <div className="glass-panel p-6">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center">
                            <Shield className="w-5 h-5 mr-3 text-primary" />
                            Account Information
                        </h3>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div className="space-y-1">
                                <p className="text-xs font-medium text-textMuted uppercase tracking-wider">User ID</p>
                                <p className="text-white font-mono">#{user.id}</p>
                            </div>
                            <div className="space-y-1">
                                <p className="text-xs font-medium text-textMuted uppercase tracking-wider">Account Role</p>
                                <div className="flex items-center">
                                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-primary/10 text-primary border border-primary/20">
                                        {user.roles?.[0] || 'User'}
                                    </span>
                                </div>
                            </div>
                            <div className="space-y-1">
                                <p className="text-xs font-medium text-textMuted uppercase tracking-wider">Username</p>
                                <p className="text-white">{user.username}</p>
                            </div>
                            <div className="space-y-1">
                                <p className="text-xs font-medium text-textMuted uppercase tracking-wider">Status</p>
                                <p className="text-primary flex items-center">
                                    <span className="w-2 h-2 rounded-full bg-primary mr-2 shadow-[0_0_8px_#00ff9d]"></span>
                                    Active
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="glass-panel p-6">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center">
                            <Key className="w-5 h-5 mr-3 text-secondary" />
                            Security
                        </h3>
                        <p className="text-sm text-textMuted mb-6">
                            Manage your security settings and session preferences.
                        </p>
                        <div className="space-y-4">
                            <button className="w-full text-left px-4 py-4 rounded-xl bg-surface border border-border hover:border-primary/50 transition-all flex justify-between items-center group">
                                <div>
                                    <p className="text-white font-medium">Change Password</p>
                                    <p className="text-xs text-textMuted">Update your login credentials</p>
                                </div>
                                <Shield className="w-5 h-5 text-textMuted group-hover:text-primary transition-colors" />
                            </button>
                            <button className="w-full text-left px-4 py-4 rounded-xl bg-surface border border-border hover:border-secondary/50 transition-all flex justify-between items-center group">
                                <div>
                                    <p className="text-white font-medium">Two-Factor Authentication</p>
                                    <p className="text-xs text-textMuted">Add an extra layer of security</p>
                                </div>
                                <Activity className="w-5 h-5 text-textMuted group-hover:text-secondary transition-colors" />
                            </button>
                        </div>
                    </div>
                </div>

                {/* Sidebar Info */}
                <div className="space-y-6">
                    <div className="glass-panel p-6">
                        <h3 className="text-lg font-bold text-white mb-4 flex items-center">
                            <Calendar className="w-5 h-5 mr-3 text-textMuted" />
                            Activity
                        </h3>
                        <div className="space-y-4">
                            <div className="border-l-2 border-primary/30 pl-4 py-1">
                                <p className="text-xs text-textMuted">Last Login</p>
                                <p className="text-sm text-white">{new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}</p>
                            </div>
                            <div className="border-l-2 border-border pl-4 py-1">
                                <p className="text-xs text-textMuted">Member Since</p>
                                <p className="text-sm text-white">Feb 2026</p>
                            </div>
                        </div>
                    </div>

                    <div className="glass-panel p-6 bg-gradient-to-br from-primary/5 via-transparent to-transparent">
                        <h3 className="text-sm font-bold text-white mb-2 uppercase tracking-widest">Pro Account</h3>
                        <p className="text-xs text-textMuted mb-4">You are currently on the professional tier with access to all DSA algorithms.</p>
                        <div className="w-full bg-surface h-2 rounded-full overflow-hidden">
                            <div className="bg-primary h-full w-full shadow-[0_0_10px_#00ff9d]"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
