import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import api from "../services/api";

const Analysis = () => {
    const { symbol } = useParams();
    const navigate = useNavigate();
    const [search, setSearch] = useState(symbol || "AAPL");
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);

    const [error, setError] = useState("");

    const fetchData = (ticker) => {
        setLoading(true);
        setError("");
        api.get(`/analyze/${ticker}`)
            .then(res => {
                setData(res.data);
                setLoading(false);
            })
            .catch(err => {
                console.error("Analysis fetch error:", err);
                setError("Failed to load analysis data. Please try again.");
                setLoading(false);
            });
    };

    useEffect(() => {
        if (symbol) {
            fetchData(symbol);
        } else {
            fetchData("AAPL");
        }
    }, [symbol]);

    const handleSearch = (e) => {
        e.preventDefault();
        if (search.trim()) {
            navigate(`/analysis/${search.toUpperCase()}`);
        }
    };

    const chartData = data?.historicalPrices?.map((price, index) => ({
        day: index + 1,
        price: price
    })) || [];

    return (
        <div className="space-y-6">
            {/* Search Bar */}
            <form onSubmit={handleSearch} className="flex gap-4">
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-textMuted w-5 h-5" />
                    <input
                        type="text"
                        className="input-field pl-10"
                        placeholder="Search stock symbol (e.g., TSLA)..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
                <button type="submit" className="bg-primary text-background font-bold px-6 rounded-lg hover:bg-primary/90">
                    Analyze
                </button>
            </form>

            {loading ? (
                <div className="text-center py-20 text-primary animate-pulse">Running Algorithms...</div>
            ) : error ? (
                <div className="text-center py-20 text-red-500 bg-red-500/10 rounded-lg border border-red-500/50">
                    <p>{error}</p>
                    <button onClick={() => fetchData(symbol || "AAPL")} className="mt-4 text-sm underline hover:text-white">Retry</button>
                </div>
            ) : data ? (
                <>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Main Chart */}
                        <div className="lg:col-span-2 glass-panel p-6">
                            <div className="flex justify-between items-center mb-6">
                                <div>
                                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                                        {data.symbol}
                                        <span className="text-sm font-normal text-textMuted bg-surface px-2 py-1 rounded border border-border">{data.trend}</span>
                                    </h2>
                                </div>
                            </div>

                            <div className="h-[400px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={chartData}>
                                        <defs>
                                            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                                                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                        <XAxis dataKey="day" stroke="#666" />
                                        <YAxis domain={['auto', 'auto']} stroke="#666" />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                                            itemStyle={{ color: '#fff' }}
                                        />
                                        <Area type="monotone" dataKey="price" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorPrice)" />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Algorithmic Stats */}
                        <div className="space-y-6">
                            <div className="glass-panel p-6">
                                <h3 className="text-lg font-semibold text-white mb-4">Algorithmic Insights</h3>
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center border-b border-border pb-2">
                                        <span className="text-textMuted">Volatility (StdDev)</span>
                                        <span className="font-mono text-accent">{data.volatility?.toFixed(2)}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-b border-border pb-2">
                                        <span className="text-textMuted">Max Profit (Kadane)</span>
                                        <span className="font-mono text-primary">+${data.maxProfit?.toFixed(2)}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-b border-border pb-2">
                                        <span className="text-textMuted">Moving Average (5D)</span>
                                        <span className="font-mono text-white">
                                            {data.movingAverage && data.movingAverage.length > 0
                                                ? `$${data.movingAverage[data.movingAverage.length - 1].toFixed(2)}`
                                                : 'N/A'}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="glass-panel p-6 bg-surface/30">
                                <h3 className="text-lg font-semibold text-white mb-4">Recommendation</h3>
                                <div className="text-center py-4">
                                    <span className={`text-3xl font-bold ${data.trend === 'Uptrend' ? 'text-primary neon-text' : 'text-red-500'}`}>
                                        {data.trend === 'Uptrend' ? 'STRONG BUY' : data.trend === 'Downtrend' ? 'SELL' : 'HOLD'}
                                    </span>
                                    <p className="text-textMuted mt-2 text-sm">Based on Prefix Sum Trend Detection</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            ) : null}
        </div>
    );
};

export default Analysis;
