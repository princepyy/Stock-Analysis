import { useEffect, useState } from "react";
import { Plus, Minus, RefreshCw } from "lucide-react";
import api from "../services/api";

const Portfolio = () => {
    const [portfolio, setPortfolio] = useState([]);
    const [stocks, setStocks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedStock, setSelectedStock] = useState("");
    const [quantity, setQuantity] = useState(1);
    const [action, setAction] = useState("buy");

    useEffect(() => {
        fetchPortfolio();
        fetchStocks();
    }, []);

    const fetchPortfolio = () => {
        api.get("/portfolio")
            .then(res => {
                setPortfolio(res.data);
                setLoading(false);
            });
    };

    const fetchStocks = () => {
        api.get("/stocks").then(res => setStocks(res.data));
    };

    const handleTransaction = async (e) => {
        e.preventDefault();
        try {
            await api.post(`/portfolio/${action}`, {
                stockId: selectedStock,
                quantity: parseInt(quantity)
            });
            fetchPortfolio();
            alert("Transaction Successful!");
        } catch (err) {
            alert("Transaction Failed");
        }
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Holdings Table */}
                <div className="lg:col-span-2 glass-panel p-6">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-white">Current Holdings</h2>
                        <button onClick={fetchPortfolio} className="p-2 hover:bg-surface rounded-full transition-colors">
                            <RefreshCw className="w-5 h-5 text-textMuted" />
                        </button>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="text-xs text-textMuted uppercase border-b border-border">
                                <tr>
                                    <th className="py-3 px-4">Symbol</th>
                                    <th className="py-3 px-4">Quantity</th>
                                    <th className="py-3 px-4">Avg Price</th>
                                    <th className="py-3 px-4">Current Value</th>
                                    <th className="py-3 px-4">P&L</th>
                                </tr>
                            </thead>
                            <tbody>
                                {portfolio.map((item) => {
                                    const currentPrice = item.stock?.currentPrice || 0;
                                    const value = currentPrice * item.quantity;
                                    const pnl = (currentPrice - item.avgBuyPrice) * item.quantity;

                                    return (
                                        <tr key={item.id} className="border-b border-border hover:bg-surface/50 transition-colors">
                                            <td className="py-3 px-4 font-bold text-white">{item.stock?.symbol}</td>
                                            <td className="py-3 px-4 text-textMuted">{item.quantity}</td>
                                            <td className="py-3 px-4 font-mono text-textMuted">${item.avgBuyPrice.toFixed(2)}</td>
                                            <td className="py-3 px-4 font-mono text-white">${value.toFixed(2)}</td>
                                            <td className={`py-3 px-4 font-mono ${pnl >= 0 ? 'text-primary' : 'text-red-500'}`}>
                                                {pnl >= 0 ? '+' : ''}{pnl.toFixed(2)}
                                            </td>
                                        </tr>
                                    );
                                })}
                                {portfolio.length === 0 && (
                                    <tr>
                                        <td colSpan="5" className="text-center py-8 text-textMuted">No stocks in portfolio</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Trade Panel */}
                <div className="glass-panel p-6 h-fit">
                    <h3 className="text-lg font-bold text-white mb-6">Quick Trade</h3>

                    <div className="flex gap-2 mb-6 bg-surface p-1 rounded-lg">
                        <button
                            onClick={() => setAction("buy")}
                            className={`flex-1 py-2 rounded-md font-medium text-sm transition-all ${action === "buy" ? "bg-primary text-background shadow-lg" : "text-textMuted hover:text-white"}`}
                        >
                            Buy
                        </button>
                        <button
                            onClick={() => setAction("sell")}
                            className={`flex-1 py-2 rounded-md font-medium text-sm transition-all ${action === "sell" ? "bg-red-500 text-white shadow-lg" : "text-textMuted hover:text-white"}`}
                        >
                            Sell
                        </button>
                    </div>

                    <form onSubmit={handleTransaction} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-textMuted mb-2">Select Asset</label>
                            <select
                                className="input-field"
                                value={selectedStock}
                                onChange={(e) => setSelectedStock(e.target.value)}
                                required
                            >
                                <option value="">Select a stock...</option>
                                {stocks.map(s => (
                                    <option key={s.id} value={s.id}>{s.symbol} - {s.name}</option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-textMuted mb-2">Quantity</label>
                            <div className="flex items-center">
                                <button type="button" onClick={() => setQuantity(q => Math.max(1, q - 1))} className="p-3 bg-surface border border-border rounded-l-lg hover:bg-white/5">
                                    <Minus className="w-4 h-4 text-white" />
                                </button>
                                <input
                                    type="number"
                                    className="w-full bg-surface border-y border-border py-3 text-center text-white focus:outline-none"
                                    value={quantity}
                                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                                />
                                <button type="button" onClick={() => setQuantity(q => q + 1)} className="p-3 bg-surface border border-border rounded-r-lg hover:bg-white/5">
                                    <Plus className="w-4 h-4 text-white" />
                                </button>
                            </div>
                        </div>

                        <div className="pt-4 border-t border-border mt-4">
                            <div className="flex justify-between mb-2">
                                <span className="text-textMuted text-sm">Estimated Total</span>
                                <span className="text-white font-mono font-bold">$
                                    {(stocks.find(s => s.id == selectedStock)?.currentPrice * quantity || 0).toFixed(2)}
                                </span>
                            </div>
                            <button type="submit" className={`btn-primary w-full mt-2 ${action === 'sell' ? '!bg-red-500 !shadow-[0_0_15px_rgba(239,68,68,0.3)]' : ''}`}>
                                {action === 'buy' ? 'Place Buy Order' : 'Place Sell Order'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Portfolio;
