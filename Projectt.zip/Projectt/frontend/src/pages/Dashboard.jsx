import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DollarSign, TrendingUp, Activity, BarChart3 } from "lucide-react";
import StatsCard from "../components/StatsCard";
import api from "../services/api";

const Dashboard = () => {
    const navigate = useNavigate();
    const [stocks, setStocks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [portfolioStats, setPortfolioStats] = useState({
        netExposure: 0,
        grossExposure: 0,
        dailyPnL: 0,
        openPositions: 0
    });

    // Mock data for the chart
    const data = [
        { name: 'Mon', value: 4000 },
        { name: 'Tue', value: 3000 },
        { name: 'Wed', value: 5000 },
        { name: 'Thu', value: 2780 },
        { name: 'Fri', value: 6890 },
        { name: 'Sat', value: 8390 },
        { name: 'Sun', value: 5490 },
    ];

    useEffect(() => {
        const fetchData = async () => {
            try {
                // Fetch stocks
                const stocksRes = await api.get("/stocks");
                setStocks(stocksRes.data.slice(0, 5));

                // Fetch portfolio for stats
                const portfolioRes = await api.get("/portfolio");
                const portfolio = portfolioRes.data;

                let netExposure = 0;
                let dailyPnL = 0;

                portfolio.forEach(item => {
                    if (!item.stock) return;
                    const value = (item.stock.currentPrice || 0) * item.quantity;
                    netExposure += value;
                    // Daily P&L = quantity * dailyChange (assuming dailyChange is absolute change)
                    // If dailyChange is percent, value * (dailyChange/100)
                    if (item.stock.dailyChange) {
                        dailyPnL += value * (item.stock.dailyChange / 100);
                    }
                });

                setPortfolioStats({
                    netExposure: netExposure,
                    grossExposure: netExposure, // Assuming long only
                    dailyPnL: dailyPnL,
                    openPositions: portfolio.length
                });

                setLoading(false);
            } catch (err) {
                console.error("Failed to fetch dashboard data", err);
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatsCard
                    title="Net Exposure"
                    value={formatCurrency(portfolioStats.netExposure)}
                    change="2.5"
                    isPositive={true}
                    icon={DollarSign}
                />
                <StatsCard
                    title="Gross Exposure"
                    value={formatCurrency(portfolioStats.grossExposure)}
                    change="1.2"
                    isPositive={true}
                    icon={Activity}
                />
                <StatsCard
                    title="Daily P&L"
                    value={formatCurrency(portfolioStats.dailyPnL)}
                    change={(portfolioStats.dailyPnL >= 0 ? "+" : "") + (portfolioStats.netExposure > 0 ? ((portfolioStats.dailyPnL / portfolioStats.netExposure) * 100).toFixed(2) : "0")}
                    isPositive={portfolioStats.dailyPnL >= 0}
                    icon={TrendingUp}
                />
                <StatsCard
                    title="Open Positions"
                    value={portfolioStats.openPositions}
                    isPositive={true}
                    icon={BarChart3}
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 glass-panel p-6">
                    <h3 className="text-lg font-semibold text-white mb-6">Exposure History</h3>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={data}>
                                <defs>
                                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#00ff9d" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="#00ff9d" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                <XAxis dataKey="name" stroke="#666" />
                                <YAxis stroke="#666" />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                                    itemStyle={{ color: '#fff' }}
                                />
                                <Area type="monotone" dataKey="value" stroke="#00ff9d" fillOpacity={1} fill="url(#colorValue)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="glass-panel p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Top Movers</h3>
                    <div className="space-y-4">
                        {loading ? (
                            <p className="text-textMuted">Loading market data...</p>
                        ) : (
                            stocks.map((stock) => (
                                <div
                                    key={stock.id}
                                    className="flex justify-between items-center p-3 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                                    onClick={() => navigate(`/analysis/${stock.symbol}`)}
                                >
                                    <div className="flex items-center space-x-3">
                                        <div className="w-8 h-8 rounded bg-surface border border-border flex items-center justify-center font-bold text-xs">
                                            {stock.symbol.substring(0, 2)}
                                        </div>
                                        <div>
                                            <h4 className="font-medium text-white">{stock.symbol}</h4>
                                            <p className="text-xs text-textMuted">{stock.name}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-white font-mono">${stock.currentPrice}</p>
                                        <p className={`text-xs ${stock.dailyChange >= 0 ? "text-primary" : "text-red-500"}`}>
                                            {stock.dailyChange >= 0 ? "+" : ""}{stock.dailyChange}%
                                        </p>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
