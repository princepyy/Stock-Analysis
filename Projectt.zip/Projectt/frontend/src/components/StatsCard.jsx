const StatsCard = ({ title, value, change, isPositive, icon: Icon }) => {
    return (
        <div className="glass-panel p-6 flex flex-col justify-between hover:bg-surface/70 transition-colors">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-textMuted text-sm font-medium uppercase tracking-wider">{title}</h3>
                    <p className="text-2xl font-bold mt-1 text-white">{value}</p>
                </div>
                <div className={`p-2 rounded-lg ${isPositive ? 'bg-primary/20 text-primary' : 'bg-red-500/20 text-red-500'}`}>
                    <Icon className="w-5 h-5" />
                </div>
            </div>

            {change && (
                <div className="flex items-center text-sm">
                    <span className={isPositive ? 'text-primary' : 'text-red-500'}>
                        {isPositive ? '+' : ''}{change}%
                    </span>
                    <span className="text-textMuted ml-2">vs last month</span>
                </div>
            )}
        </div>
    );
};

export default StatsCard;
