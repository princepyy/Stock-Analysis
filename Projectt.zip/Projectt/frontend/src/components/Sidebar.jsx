import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, BarChart2, Briefcase, LogOut, TrendingUp, Activity, User } from "lucide-react";
import clsx from "clsx";
import AuthService from "../services/auth.service";

const Sidebar = () => {
    const location = useLocation();

    const handleLogout = () => {
        AuthService.logout();
        window.location.reload();
    };

    const menuItems = [
        { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
        { icon: Briefcase, label: "Portfolio", path: "/portfolio" },
        { icon: TrendingUp, label: "Analysis", path: "/analysis/AAPL" }, // Default to AAPL
        { icon: User, label: "Profile", path: "/profile" },
    ];

    return (
        <div className="w-64 bg-surface border-r border-border h-full flex flex-col">
            <div className="p-6 flex items-center space-x-3 border-b border-border">
                <Activity className="w-8 h-8 text-primary" />
                <h1 className="text-xl font-bold tracking-tighter neon-text text-white">StockPro</h1>
            </div>

            <nav className="flex-1 p-4 space-y-2">
                {menuItems.map((item) => {
                    const isActive = location.pathname.startsWith(item.path.split('/')[1]);
                    // simple active check

                    return (
                        <Link
                            key={item.path}
                            to={item.path}
                            className={clsx(
                                "flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200",
                                isActive
                                    ? "bg-primary/10 text-primary border-l-4 border-primary"
                                    : "text-textMuted hover:bg-white/5 hover:text-white"
                            )}
                        >
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.label}</span>
                        </Link>
                    );
                })}
            </nav>

            <div className="p-4 border-t border-border">
                <button
                    onClick={handleLogout}
                    className="flex items-center space-x-3 px-4 py-3 w-full text-left text-accent hover:bg-accent/10 rounded-lg transition-colors"
                >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium">Logout</span>
                </button>
            </div>
        </div>
    );
};

export default Sidebar;
