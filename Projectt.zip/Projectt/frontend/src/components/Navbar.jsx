import { Link } from "react-router-dom";
import AuthService from "../services/auth.service";

const Navbar = () => {
    const user = AuthService.getCurrentUser();

    return (
        <header className="bg-surface/50 border-b border-border h-16 flex items-center justify-between px-6 backdrop-blur-sm">
            <h2 className="text-xl font-semibold text-textMain">Overview</h2>

            <Link to="/profile" className="flex items-center space-x-4 hover:opacity-80 transition-opacity">
                <div className="text-right hidden sm:block">
                    <p className="text-sm font-medium text-white">{user?.username}</p>
                    <p className="text-xs text-textMuted">{user?.email}</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center font-bold text-background shadow-[0_0_10px_rgba(0,255,157,0.2)]">
                    {user?.username?.charAt(0).toUpperCase()}
                </div>
            </Link>
        </header>
    );
};

export default Navbar;
