import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

const Layout = () => {
    return (
        <div className="flex h-screen bg-background overflow-hidden relative">
            <Sidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Navbar />
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-6">
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

export default Layout;
