/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                background: "#0a0a0a", // Dark Bloomberg-like background
                surface: "#1a1a1a",
                primary: "#00ff9d", // Neon Green
                secondary: "#8b5cf6", // Purple
                accent: "#f43f5e",
                textMain: "#ffffff",
                textMuted: "#a3a3a3",
                border: "#2a2a2a"
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
                mono: ['JetBrains Mono', 'monospace'],
            },
        },
    },
    plugins: [],
}
