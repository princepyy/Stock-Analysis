package com.stockanalyzer.controller;

import com.stockanalyzer.service.StockAnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/analyze")
public class AnalysisController {

    @Autowired
    private StockAnalysisService analysisService;

    // Mock functionality to analyze a stock symbol
    @GetMapping("/{symbol}")
    public Map<String, Object> analyzeStock(@PathVariable String symbol) {
        // Generate mock historical data for demonstration
        List<Double> historicalPrices = new ArrayList<>();
        double basePrice = 100 + new Random().nextInt(50);
        for(int i=0; i<30; i++) {
            basePrice += (new Random().nextDouble() - 0.5) * 5; 
            if(basePrice < 0) basePrice = 1.0;
            historicalPrices.add(Math.round(basePrice * 100.0) / 100.0);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("symbol", symbol);
        result.put("historicalPrices", historicalPrices);
        result.put("movingAverage", analysisService.calculateMovingAverage(historicalPrices, 5));
        result.put("maxProfit", analysisService.calculateMaxProfit(historicalPrices));
        result.put("volatility", analysisService.calculateVolatility(historicalPrices));
        result.put("trend", analysisService.detectTrend(historicalPrices));
        
        double[] priceArray = historicalPrices.stream().mapToDouble(Double::doubleValue).toArray();
        result.put("stockSpan", analysisService.calculateStockSpan(priceArray));
        
        return result;
    }
}
