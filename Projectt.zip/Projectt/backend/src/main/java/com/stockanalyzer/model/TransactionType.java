package com.stockanalyzer.model;

public enum TransactionType {
    BUY,
    SELL
}
