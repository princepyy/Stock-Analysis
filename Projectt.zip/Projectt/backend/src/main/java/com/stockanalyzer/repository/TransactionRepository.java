package com.stockanalyzer.repository;

import com.stockanalyzer.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByUserId(Long userId);
    List<Transaction> findTop5ByUserIdOrderByTimestampDesc(Long userId);
}
