package com.stockanalyzer.config;

import com.stockanalyzer.model.Role;
import com.stockanalyzer.model.Stock;
import com.stockanalyzer.model.User;
import com.stockanalyzer.repository.StockRepository;
import com.stockanalyzer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        loadStocks();
        loadUsers();
    }

    private void loadStocks() {
        if (stockRepository.count() == 0) {
            List<Stock> stocks = List.of(
                    new Stock(null, "AAPL", "Apple Inc.", 175.50, 1.25, "Technology", LocalDate.of(1980, 12, 12)),
                    new Stock(null, "GOOGL", "Alphabet Inc.", 140.20, -0.45, "Technology", LocalDate.of(2004, 8, 19)),
                    new Stock(null, "AMZN", "Amazon.com", 178.15, 2.10, "Consumer Discretionary",
                            LocalDate.of(1997, 5, 15)),
                    new Stock(null, "MSFT", "Microsoft Corp.", 410.30, 0.85, "Technology", LocalDate.of(1986, 3, 13)),
                    new Stock(null, "TSLA", "Tesla Inc.", 205.60, -1.50, "Automotive", LocalDate.of(2010, 6, 29)),
                    new Stock(null, "NVDA", "NVIDIA Corp.", 788.10, 3.45, "Technology", LocalDate.of(1999, 1, 22)),
                    new Stock(null, "JPM", "JPMorgan Chase", 183.50, 0.65, "Financials", LocalDate.of(1969, 5, 27)),
                    new Stock(null, "V", "Visa Inc.", 279.40, 1.15, "Financials", LocalDate.of(2008, 3, 19)),
                    new Stock(null, "WMT", "Walmart Inc.", 59.30, -0.25, "Consumer Staples", LocalDate.of(1972, 8, 25)),
                    new Stock(null, "PG", "Procter & Gamble", 159.20, 0.10, "Consumer Staples",
                            LocalDate.of(1890, 1, 1)));
            stockRepository.saveAll(stocks);
        }
    }

    private void loadUsers() {
        if (userRepository.count() == 0) {
            User admin = User.builder()
                    .username("admin")
                    .email("admin@stock.com")
                    .password(passwordEncoder.encode("admin123"))
                    .role(Role.ADMIN)
                    .build();
            userRepository.save(admin);

            User user = User.builder()
                    .username("user")
                    .email("user@stock.com")
                    .password(passwordEncoder.encode("user123"))
                    .role(Role.USER)
                    .build();
            userRepository.save(user);
        }
    }
}
