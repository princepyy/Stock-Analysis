package com.stockanalyzer.controller;

import com.stockanalyzer.model.Portfolio;
import com.stockanalyzer.model.Transaction;
import com.stockanalyzer.model.User;
import com.stockanalyzer.repository.UserRepository;
import com.stockanalyzer.service.PortfolioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/portfolio")
public class PortfolioController {

    @Autowired
    private PortfolioService portfolioService;

    @Autowired
    private UserRepository userRepository;

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() ||
                authentication.getPrincipal().equals("anonymousUser")) {
            // Fallback for demo/testing if auth fails or is bypassed
            return userRepository.findByUsername("user")
                    .map(User::getId)
                    .orElse(1L);
        }

        String username = authentication.getName();
        return userRepository.findByUsername(username)
                .map(User::getId)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @GetMapping
    public List<Portfolio> getPortfolio() {
        return portfolioService.getUserPortfolio(getCurrentUserId());
    }

    @GetMapping("/transactions")
    public List<Transaction> getTransactions() {
        return portfolioService.getUserTransactions(getCurrentUserId());
    }

    @PostMapping("/buy")
    public ResponseEntity<?> buyStock(@RequestBody Map<String, Object> request) {
        System.out.println("Processing buy request: " + request);
        try {
            Long stockId = Long.valueOf(request.get("stockId").toString());
            int quantity = Integer.parseInt(request.get("quantity").toString());
            return ResponseEntity.ok(portfolioService.buyStock(getCurrentUserId(), stockId, quantity));
        } catch (Exception e) {
            System.err.println("Error in buyStock: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/sell")
    public ResponseEntity<?> sellStock(@RequestBody Map<String, Object> request) {
        System.out.println("Processing sell request: " + request);
        try {
            Long stockId = Long.valueOf(request.get("stockId").toString());
            int quantity = Integer.parseInt(request.get("quantity").toString());
            return ResponseEntity.ok(portfolioService.sellStock(getCurrentUserId(), stockId, quantity));
        } catch (Exception e) {
            System.err.println("Error in sellStock: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
