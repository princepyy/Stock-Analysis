package com.stockanalyzer.service;

import com.stockanalyzer.model.*;
import com.stockanalyzer.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PortfolioService {

    @Autowired
    private PortfolioRepository portfolioRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StockRepository stockRepository;

    public List<Portfolio> getUserPortfolio(Long userId) {
        return portfolioRepository.findByUserId(userId);
    }
    
    public List<Transaction> getUserTransactions(Long userId) {
        return transactionRepository.findByUserId(userId);
    }

    @Transactional
    public Transaction buyStock(Long userId, Long stockId, int quantity) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Stock stock = stockRepository.findById(stockId)
                .orElseThrow(() -> new RuntimeException("Stock not found"));

        double price = stock.getCurrentPrice();
        double totalCost = price * quantity;

        // Update Portfolio
        Optional<Portfolio> existingPortfolio = portfolioRepository.findByUserIdAndStockId(userId, stockId);
        
        if (existingPortfolio.isPresent()) {
            Portfolio portfolio = existingPortfolio.get();
            double currentTotalValue = portfolio.getAvgBuyPrice() * portfolio.getQuantity();
            double newTotalValue = currentTotalValue + totalCost;
            int newQuantity = portfolio.getQuantity() + quantity;
            
            portfolio.setQuantity(newQuantity);
            portfolio.setAvgBuyPrice(newTotalValue / newQuantity);
            portfolioRepository.save(portfolio);
        } else {
            Portfolio newPortfolio = Portfolio.builder()
                    .user(user)
                    .stock(stock)
                    .quantity(quantity)
                    .avgBuyPrice(price)
                    .build();
            portfolioRepository.save(newPortfolio);
        }

        // Record Transaction
        Transaction transaction = Transaction.builder()
                .user(user)
                .stock(stock)
                .type(TransactionType.BUY)
                .quantity(quantity)
                .price(price)
                .timestamp(LocalDateTime.now())
                .build();
        
        return transactionRepository.save(transaction);
    }

    @Transactional
    public Transaction sellStock(Long userId, Long stockId, int quantity) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Stock stock = stockRepository.findById(stockId)
                .orElseThrow(() -> new RuntimeException("Stock not found"));

        Portfolio portfolio = portfolioRepository.findByUserIdAndStockId(userId, stockId)
                .orElseThrow(() -> new RuntimeException("Stock not found in portfolio"));

        if (portfolio.getQuantity() < quantity) {
            throw new RuntimeException("Insufficient stock quantity");
        }

        double price = stock.getCurrentPrice();

        // Update Portfolio
        int newQuantity = portfolio.getQuantity() - quantity;
        if (newQuantity == 0) {
            portfolioRepository.delete(portfolio);
        } else {
            portfolio.setQuantity(newQuantity);
            portfolioRepository.save(portfolio);
        }

        // Record Transaction
        Transaction transaction = Transaction.builder()
                .user(user)
                .stock(stock)
                .type(TransactionType.SELL)
                .quantity(quantity)
                .price(price)
                .timestamp(LocalDateTime.now())
                .build();

        return transactionRepository.save(transaction);
    }
}
