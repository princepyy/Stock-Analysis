package com.stockanalyzer.service;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class StockAnalysisService {

    // 1. Moving Average (Sliding Window)
    public List<Double> calculateMovingAverage(List<Double> prices, int windowSize) {
        List<Double> movingAverages = new ArrayList<>();
        if (prices == null || prices.size() < windowSize) return movingAverages;

        double windowSum = 0;
        for (int i = 0; i < windowSize; i++) {
            windowSum += prices.get(i);
        }
        movingAverages.add(windowSum / windowSize);

        for (int i = windowSize; i < prices.size(); i++) {
            windowSum += prices.get(i) - prices.get(i - windowSize);
            movingAverages.add(windowSum / windowSize);
        }

        return movingAverages;
    }

    // 2. Maximum Profit (Kadane’s Variation)
    // Returns max profit if bought once and sold once
    public Double calculateMaxProfit(List<Double> prices) {
        if (prices == null || prices.size() < 2) return 0.0;
        
        double minPrice = prices.get(0);
        double maxProfit = 0.0;

        for (int i = 1; i < prices.size(); i++) {
            minPrice = Math.min(minPrice, prices.get(i));
            maxProfit = Math.max(maxProfit, prices.get(i) - minPrice);
        }
        return maxProfit;
    }

    // 3. Stock Span (Stack)
    // Returns span for each day
    public int[] calculateStockSpan(double[] prices) {
        int n = prices.length;
        int[] spans = new int[n];
        Stack<Integer> stack = new Stack<>(); 
        
        stack.push(0);
        spans[0] = 1;
        
        for (int i = 1; i < n; i++) {
            while (!stack.isEmpty() && prices[stack.peek()] <= prices[i]) {
                stack.pop();
            }
            spans[i] = (stack.isEmpty()) ? (i + 1) : (i - stack.peek());
            stack.push(i);
        }
        return spans;
    }

    // 4. Trend Detection (Simple Linear Regression Slope or just direction)
    public String detectTrend(List<Double> prices) {
        if (prices == null || prices.size() < 2) return "Neutral";
        
        double first = prices.get(0);
        double last = prices.get(prices.size() - 1);
        
        if (last > first * 1.05) return "Uptrend";
        if (last < first * 0.95) return "Downtrend";
        return "Sideways";
    }

    // 5. Volatility (Standard Deviation)
    public Double calculateVolatility(List<Double> prices) {
        if (prices == null || prices.isEmpty()) return 0.0;

        double mean = prices.stream().mapToDouble(val -> val).average().orElse(0.0);
        double variance = 0.0;
        for (double p : prices) {
            variance += Math.pow(p - mean, 2);
        }
        return Math.sqrt(variance / prices.size());
    }

    // 6. Binary Search for Price (Find closest occurrence)
    public int searchPriceIndex(List<Double> sortedPrices, double targetPrice) {
        int left = 0, right = sortedPrices.size() - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (sortedPrices.get(mid) == targetPrice) return mid;
            if (sortedPrices.get(mid) < targetPrice) left = mid + 1;
            else right = mid - 1;
        }
        return -1; 
    }
}
