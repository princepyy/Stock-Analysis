package com.stockanalyzer.model;

public enum Role {
    USER,
    ADMIN
}
